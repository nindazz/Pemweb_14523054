import React from "react";


function footer() {
    const namaMhs = "azarine"
    return (
        <div>
            <h3> Ini halaman footer</h3>
            <footer> design by me with 💋 </footer>
        </div>
    );
}

export default footer;